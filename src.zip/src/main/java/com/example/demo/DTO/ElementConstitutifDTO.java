package com.example.demo.DTO;


public class ElementConstitutifDTO {
	
//    private UniteEnseignementDTO uniteEnseignement;

    private String designation;

    private String description;



	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	

    

}
