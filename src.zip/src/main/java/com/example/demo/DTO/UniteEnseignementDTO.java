package com.example.demo.DTO;

public class UniteEnseignementDTO {

}
