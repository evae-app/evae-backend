package com.example.demo.models;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.LinkedHashSet;
import java.util.Set;

@Getter
@Setter
@Entity
@Table(name = "FORMATION", schema = "SPI")
public class Formation {
    @Id
    @SequenceGenerator(name = "FORMATION_id_gen", sequenceName = "AUT_SEQ", allocationSize = 1)
    @Column(name = "CODE_FORMATION", nullable = false, length = 8)
    private String codeFormation;

    @Column(name = "DIPLOME", nullable = false, length = 3)
    private String diplome;

    @Column(name = "N0_ANNEE", nullable = false)
    private Boolean n0Annee = false;

    @Column(name = "NOM_FORMATION", nullable = false, length = 64)
    private String nomFormation;

    @Column(name = "DOUBLE_DIPLOME", nullable = false)
    private Boolean doubleDiplome = false;

    @Column(name = "DEBUT_ACCREDITATION")
    private LocalDate debutAccreditation;

    @Column(name = "FIN_ACCREDITATION")
    private LocalDate finAccreditation;

    @OneToMany(mappedBy = "codeFormation")
    private Set<Promotion> promotions = new LinkedHashSet<>();

    @OneToMany(mappedBy = "codeFormation")
    private Set<UniteEnseignement> uniteEnseignements = new LinkedHashSet<>();

}